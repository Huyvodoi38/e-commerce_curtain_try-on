# Đồ án tốt nghiệp — Quang Huy Shop

Báo cáo LaTeX theo template SOICT (ứng dụng).

## Biên dịch

Yêu cầu: TeX Live (pdflatex, biber hoặc bibtex).

```bash
cd SOICT_DATN_Application_VIE_Template
pdflatex DoAn.tex
bibtex DoAn
pdflatex DoAn.tex
pdflatex DoAn.tex
```

Hoặc dùng TeXstudio / Overleaf: mở file `DoAn.tex` làm main document.

## Cần chỉnh trước khi nộp

1. **Bìa** (`Bia.tex`, `Bia_lot.tex`): họ tên, email `@sis.hust.edu.vn`, tên GVHD, tháng/năm.
2. **Lời cảm ơn** (`Chuong/0_2_Loi_cam_on.tex`).
3. **Hình minh họa**: chụp màn hình hệ thống, lưu vào `Hinhve/`, chèn vào Chương 4 mục 4.3.3.
4. **Biểu đồ use case**: vẽ bằng draw.io/PlantUML, thêm vào Chương 2 nếu GVHD yêu cầu.
5. Kiểm tra `\cite{}` và chạy đủ vòng bibtex.

## Nội dung đã điền

- Tóm tắt Việt/Anh theo dự án Quang Huy Shop
- 6 chương + phụ lục use case
- Danh mục viết tắt: API, JWT, ODM, RBAC, REST, AI, GPU, CDN
- Tài liệu tham khảo cập nhật (FastAPI, React, MongoDB, VNPay, SAM, LDM,...)
